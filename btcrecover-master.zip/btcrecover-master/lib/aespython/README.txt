
The software in this directory is originally attributed to:

    Copyright (c) 2010, Adam Newman http://www.caller9.com/
    Licensed under the MIT license http://www.opensource.org/licenses/mit-license.php

This software was later optimized by, and has been downloaded from:

    Demur Rumed
    https://github.com/serprex/pythonaes
